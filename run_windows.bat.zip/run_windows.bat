@echo off
:: Cambiar al directorio donde esta este archivo (sea donde sea que este)
cd /d "%~dp0"
title SEACE Buscador
echo.
echo  ============================================
echo          SEACE Buscador
echo      Iniciando aplicacion, espere...
echo  ============================================
echo.

:: Intentar con el lanzador de Windows (py), luego con python
where py >nul 2>&1
if not errorlevel 1 (
    set PYTHON=py
    goto :found
)
where python >nul 2>&1
if not errorlevel 1 (
    set PYTHON=python
    goto :found
)
where python3 >nul 2>&1
if not errorlevel 1 (
    set PYTHON=python3
    goto :found
)

echo ERROR: Python no esta instalado o no se encontro.
echo.
echo Por favor descargue e instale Python desde:
echo https://www.python.org/downloads/
echo.
echo IMPORTANTE: Durante la instalacion marque la opcion
echo "Add Python to PATH" antes de hacer clic en Install.
echo.
pause
exit /b 1

:found
echo Usando: %PYTHON%
%PYTHON% --version
echo.

:: Crear entorno virtual si no existe
if not exist ".venv" (
    echo Configurando entorno por primera vez (solo ocurre una vez, espere)...
    %PYTHON% -m venv .venv
    if errorlevel 1 (
        echo.
        echo ERROR: No se pudo crear el entorno virtual.
        echo Intente ejecutar este archivo como Administrador.
        pause
        exit /b 1
    )
    echo Entorno creado correctamente.
    echo.
)

:: Activar entorno virtual
call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo ERROR: No se pudo activar el entorno virtual.
    pause
    exit /b 1
)

:: Instalar/actualizar dependencias si no estan instaladas
python -c "import customtkinter" >nul 2>&1
if errorlevel 1 (
    echo Instalando dependencias (solo ocurre la primera vez)...
    echo Esto puede tardar 2-3 minutos...
    echo.
    python -m pip install --quiet --upgrade pip
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo ERROR: No se pudieron instalar las dependencias.
        echo Verifique su conexion a internet e intente de nuevo.
        pause
        exit /b 1
    )
    echo.
    echo Dependencias instaladas correctamente.
    echo.
)

:: Iniciar la aplicacion
echo Iniciando SEACE Buscador...
echo.
python desktop_app.py

:: Si la app se cierra con error, mostrar mensaje
if errorlevel 1 (
    echo.
    echo La aplicacion se cerro inesperadamente.
    echo Contacte al administrador del sistema.
    echo.
    pause
)
